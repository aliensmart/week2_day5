## Database Terminal Teller

Rewrite your object-oriented Terminal Teller to use a sqlite3 database instead of a .json text file.

All data should be stored in the database. Aside from (optionally) a csv of initial values, you should not be reading or writing text files.

